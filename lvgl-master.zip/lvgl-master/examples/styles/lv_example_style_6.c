typedef int _keep_pedantic_happy;
