C
^

Simple Switch 
"""""""""""""""""""""""

.. lv_example:: widgets/lv_example_switch/lv_example_switch_1
  :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
